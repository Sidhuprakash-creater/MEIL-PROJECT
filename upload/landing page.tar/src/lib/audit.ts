import { db } from "@/lib/db";

export type AuditEvent =
  | "LOGIN_SUCCESS"
  | "LOGIN_FAILED"
  | "LOGOUT"
  | "PASSWORD_RESET_REQUESTED"
  | "RATE_LIMITED";

export interface AuditEntry {
  eventType: AuditEvent;
  result: "SUCCESS" | "FAILURE" | "INFO";
  employeeId?: string;
  userId?: string;
  portal?: string;
  role?: string;
  scopeRef?: string;
  reason?: string;
  detail?: string;
  ip?: string;
  userAgent?: string;
}

/**
 * Append to the immutable audit trail. Failures are logged to the console but
 * never break the authentication flow itself.
 */
export async function logAudit(entry: AuditEntry): Promise<void> {
  try {
    await db.auditLog.create({
      data: {
        eventType: entry.eventType,
        result: entry.result,
        employeeId: entry.employeeId,
        userId: entry.userId,
        portal: entry.portal,
        role: entry.role,
        scopeRef: entry.scopeRef,
        reason: entry.reason,
        detail: entry.detail,
        ip: entry.ip,
        userAgent: entry.userAgent,
      },
    });
  } catch (err) {
    console.error("[audit] failed to record entry:", entry.eventType, err);
  }
}
