"use client";

/* ═══════════════════════════════════════════════════════════════════════════
   MEIL ESG — SESSION DASHBOARD SHELL
   The verified post-login destination. Everything displayed here comes from
   the server session (/api/auth/session) — never from client-side state the
   user could tamper with. ESG dashboard modules connect into this shell.
   ═══════════════════════════════════════════════════════════════════════════ */

import { useCallback, useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  BadgeCheck,
  Building2,
  Clock3,
  FileClock,
  Info,
  LayoutDashboard,
  LogOut,
  ShieldCheck,
  UserCheck,
} from "lucide-react";
import {
  type SessionPayload,
  type VerifiedUser,
  scopeTypeForRole,
} from "@/lib/platform-config";

const SCOPE_LABELS: Record<string, string> = {
  group: "Group — MEIL Group (organization-wide)",
  subsidiary: "Subsidiary",
  business_unit: "Business Unit",
};

const EVENT_LABELS: Record<string, string> = {
  LOGIN_SUCCESS: "Signed in",
  LOGIN_FAILED: "Failed sign-in",
  LOGOUT: "Signed out",
  PASSWORD_RESET_REQUESTED: "Password reset requested",
  RATE_LIMITED: "Throttled attempt",
};

function formatWhen(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export default function SessionDashboard({
  initialUser,
  onExit,
}: {
  initialUser: VerifiedUser;
  onExit: () => void;
}) {
  const [session, setSession] = useState<SessionPayload | null>(null);
  const [signingOut, setSigningOut] = useState(false);
  const [provisionFlash, setProvisionFlash] = useState(false);
  const provisionRef = useRef<HTMLDivElement>(null);

  const load = useCallback(() => {
    fetch("/api/auth/session")
      .then((r) => r.json())
      .then((d: SessionPayload) => setSession(d))
      .catch(() => setSession({ authenticated: false }));
  }, []);

  useEffect(load, [load]);

  const signOut = async () => {
    if (signingOut) return;
    setSigningOut(true);
    try {
      await fetch("/api/auth/logout", { method: "POST" });
    } catch {
      /* session will expire server-side regardless */
    }
    onExit();
  };

  const user = session?.authenticated ? session.user : initialUser;
  if (!user) return null;

  const scopeType = scopeTypeForRole(user.role);
  const scopeName =
    scopeType === "group"
      ? SCOPE_LABELS.group
      : scopeType === "subsidiary"
        ? user.scope.subsidiary?.name ?? "—"
        : user.scope.businessUnit?.name ?? "—";

  return (
    <div className="ep-root">
      <div className="ep-dash">
        {/* top bar */}
        <div className="ep-dash-bar glass-dark glass-edge">
          <span className="ep-brand-mark" style={{ width: 38, height: 38, fontSize: 18 }}>
            M
          </span>
          <span className="ep-brand-text">
            <b style={{ fontSize: 14 }}>MEIL Group</b>
            <small>BRSR &amp; ESG Intelligence</small>
          </span>
          <span style={{ flex: 1 }} />
          <span className="ep-badge ep-badge--teal">
            <ShieldCheck size={11} strokeWidth={2.2} />
            Session verified
          </span>
          <button type="button" className="ep-back" onClick={onExit}>
            <ArrowLeft size={14} strokeWidth={2.2} />
            Exit to Site
          </button>
          <button
            type="button"
            className="ep-btn ep-btn-ghost"
            style={{ width: "auto", padding: "10px 18px", fontSize: 13 }}
            onClick={signOut}
            disabled={signingOut}
          >
            {signingOut ? (
              <span className="ep-spinner" aria-hidden />
            ) : (
              <LogOut size={14} strokeWidth={2.2} />
            )}
            Sign Out
          </button>
        </div>

        <main className="ep-dash-main">
          {/* hero */}
          <div className="ep-dash-hero">
            <div>
              <span className="ep-eyebrow">Access Granted · {user.roleLabel}</span>
              <h1>
                Welcome back, <em>{user.name.split(" ").slice(-1)[0]}</em>
              </h1>
              <p>
                You are signed in through the {user.roleLabel} portal. Your scope was
                verified server-side at every step — this session can only reach the
                organizational layer assigned to it.
              </p>
            </div>
            <button
              type="button"
              className="ep-btn"
              style={{ width: "auto" }}
              onClick={() => {
                provisionRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
                setProvisionFlash(true);
                setTimeout(() => setProvisionFlash(false), 2400);
              }}
            >
              <LayoutDashboard size={16} strokeWidth={2.2} />
              Continue to {user.roleLabel} Dashboard
            </button>
          </div>

          <div className="ep-dash-grid">
            {/* identity */}
            <div className="ep-dash-card glass-dark glass-edge">
              <h3>
                <UserCheck size={14} strokeWidth={2.1} />
                Verified Identity
              </h3>
              <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                <span className="ep-benefit-ico" style={{ ["--ep-accent" as string]: "var(--gold-400)", width: 50, height: 50 }}>
                  <Building2 size={22} strokeWidth={1.8} />
                </span>
                <div>
                  <div className="ep-identity-name">{user.name}</div>
                  <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, letterSpacing: "0.1em", color: "var(--tx-400)" }}>
                    {user.employeeId}
                  </span>
                </div>
              </div>
              <div className="ep-identity-rows">
                <div className="ep-identity-row">
                  <span>Assigned role</span>
                  <b>
                    <span className="ep-badge">{user.roleLabel}</span>
                  </b>
                </div>
                <div className="ep-identity-row">
                  <span>Organizational scope</span>
                  <b>{scopeName}</b>
                </div>
                <div className="ep-identity-row">
                  <span>Dashboard route</span>
                  <b>
                    <code style={{ fontFamily: "var(--font-mono)", fontSize: 12, color: "var(--gold-600)" }}>{user.dashboardPath}</code>
                  </b>
                </div>
                {session?.expiresAt && (
                  <div className="ep-identity-row">
                    <span>Session expiry</span>
                    <b>
                      <Clock3 size={12} style={{ display: "inline", marginRight: 6, verticalAlign: "-1px" }} />
                      {formatWhen(session.expiresAt)}
                    </b>
                  </div>
                )}
              </div>
            </div>

            {/* permissions + activity */}
            <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
              <div className="ep-dash-card glass-dark glass-edge">
                <h3>
                  <BadgeCheck size={14} strokeWidth={2.1} />
                  Server-Granted Permissions
                </h3>
                {user.permissions.map((p) => (
                  <div className="ep-perm" key={p}>
                    <ShieldCheck size={14} strokeWidth={2.1} />
                    {p}
                  </div>
                ))}
              </div>

              <div className="ep-dash-card glass-dark glass-edge">
                <h3>
                  <FileClock size={14} strokeWidth={2.1} />
                  Recent Activity · Audit Trail
                </h3>
                <div className="ep-activity">
                  {(session?.recentActivity ?? []).map((a, i) => (
                    <div className="ep-activity-row" key={i}>
                      <span style={{ display: "flex", alignItems: "center", gap: 9 }}>
                        <span
                          className={`ep-dot ${a.result === "SUCCESS" ? "ep-dot--ok" : a.result === "FAILURE" ? "ep-dot--bad" : "ep-dot--info"}`}
                          aria-hidden
                        />
                        <span className="ev">{EVENT_LABELS[a.eventType] ?? a.eventType}</span>
                      </span>
                      <span className="when">{formatWhen(a.createdAt)}</span>
                    </div>
                  ))}
                  {(session?.recentActivity ?? []).length === 0 && (
                    <div className="ep-activity-row">
                      <span className="when">No recorded activity yet.</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div
            ref={provisionRef}
            className={`ep-dash-note${provisionFlash ? " is-flash" : ""}`}
          >
            <Info size={15} strokeWidth={2} />
            <span>
              <strong style={{ color: "var(--tx-900)" }}>Dashboard module provisioning —</strong> the
              ESG reporting modules connect into this verified session at the route provisioned
              in <code>src/lib/platform-config.ts → DASHBOARD_PATHS</code>
              {scopeType === "group" ? " (" : " ("}
              <code>{user.dashboardPath}</code>
              {") "}. Until those modules ship, this shell proves the authenticated, role-scoped
              session end-to-end.
            </span>
          </div>
        </main>
      </div>
    </div>
  );
}
