"use client";

/* ═══════════════════════════════════════════════════════════════════════════
   MEIL ESG — APP SHELL
   Single-route experience switching (no full page reloads):
     landing   → public marketing site
     enter     → secure access gateway (portal chooser + login workflows)
     dashboard → verified session shell
   ═══════════════════════════════════════════════════════════════════════════ */

import { useCallback, useEffect, useState } from "react";
import LandingPage from "@/components/landing/landing-page";
import EnterPlatform from "@/components/enter-platform/enter-platform";
import SessionDashboard from "@/components/enter-platform/session-dashboard";
import type { SessionPayload, VerifiedUser } from "@/lib/platform-config";

type View = "landing" | "enter" | "dashboard";

export default function AppShell() {
  const [view, setView] = useState<View>("landing");
  const [session, setSession] = useState<SessionPayload | null>(null);

  /* restore an existing session + honour deep links (/?enter=1, /?dashboard=1) */
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const deepLink =
      params.get("enter") === "1"
        ? "enter"
        : params.get("dashboard") === "1"
          ? "dashboard"
          : null;

    fetch("/api/auth/session")
      .then((r) => r.json())
      .then((d: SessionPayload) => {
        setSession(d);
        if (deepLink === "enter") setView(d.authenticated ? "dashboard" : "enter");
        else if (deepLink === "dashboard") setView("dashboard");
      })
      .catch(() => {
        setSession({ authenticated: false });
        if (deepLink) setView(deepLink);
      });
  }, []);

  const handleAuthed = useCallback((user: VerifiedUser) => {
    setSession({ authenticated: true, user });
    setView("dashboard");
  }, []);

  const handleExitToSite = useCallback(() => {
    setView("landing");
    window.history.replaceState(null, "", window.location.pathname);
    window.scrollTo({ top: 0 });
  }, []);

  const handleSignOutExit = useCallback(() => {
    setSession({ authenticated: false });
    setView("enter");
  }, []);

  /* "Enter Platform" opens the dashboard when a verified session exists */
  const handleEnter = useCallback(() => {
    setView(session?.authenticated ? "dashboard" : "enter");
  }, [session]);

  if (view === "enter") {
    return <EnterPlatform onBack={handleExitToSite} onAuthed={handleAuthed} />;
  }

  if (view === "dashboard") {
    if (session === null) {
      /* session probe still in flight — brief ink splash */
      return (
        <div
          className="ep-root"
          aria-busy="true"
          aria-label="Restoring secure session"
        />
      );
    }
    if (session.authenticated && session.user) {
      return (
        <SessionDashboard initialUser={session.user} onExit={handleSignOutExit} />
      );
    }
    /* stale dashboard link without a session → gateway */
    return <EnterPlatform onBack={handleExitToSite} onAuthed={handleAuthed} />;
  }

  return <LandingPage onEnter={handleEnter} />;
}
