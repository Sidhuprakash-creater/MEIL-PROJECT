import { NextResponse } from "next/server";
import { logAudit } from "@/lib/audit";
import { clientIp, destroySession, getSessionPayload } from "@/lib/session";

export const dynamic = "force-dynamic";

/* POST /api/auth/logout — revoke the server session + clear the cookie. */
export async function POST(request: Request) {
  const payload = await getSessionPayload();
  await destroySession();

  if (payload?.user) {
    await logAudit({
      eventType: "LOGOUT",
      result: "SUCCESS",
      userId: payload.user.id,
      employeeId: payload.user.employeeId,
      ip: clientIp(request.headers),
      userAgent: request.headers.get("user-agent") ?? undefined,
    });
  }

  return NextResponse.json({ ok: true });
}
