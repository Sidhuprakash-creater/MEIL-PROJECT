import { NextResponse } from "next/server";
import { logAudit } from "@/lib/audit";
import { clientIp } from "@/lib/session";

export const dynamic = "force-dynamic";

/* ────────────────────────────────────────────────────────────────────────────
   POST /api/auth/forgot-password { employeeId }

   No e-mail delivery service is configured in this build, so the request is
   recorded on the audit trail for the ESG IT team and answered with a generic
   (non-enumerating) message. Wire a mailer/reset-token flow here later.
   ──────────────────────────────────────────────────────────────────────────── */

export async function POST(request: Request) {
  let employeeId = "";
  try {
    const body = await request.json();
    employeeId = String(body.employeeId ?? "").trim().toUpperCase();
  } catch {
    /* treated as empty below */
  }

  if (!employeeId) {
    return NextResponse.json(
      { ok: false, code: "VALIDATION", message: "Enter your Employee ID / User ID first." },
      { status: 400 }
    );
  }

  await logAudit({
    eventType: "PASSWORD_RESET_REQUESTED",
    result: "INFO",
    employeeId,
    ip: clientIp(request.headers),
    userAgent: request.headers.get("user-agent") ?? undefined,
  });

  return NextResponse.json({
    ok: true,
    message:
      "If this Employee ID is registered, password reset instructions have been issued to your registered business email. For assistance, contact ESG IT support (esg-support@meil.in).",
  });
}
