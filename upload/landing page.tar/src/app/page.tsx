import AppShell from "@/components/app-shell";
import "./landing.css";

export default function Page() {
  return <AppShell />;
}
