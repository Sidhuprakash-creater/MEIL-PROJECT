import type { Metadata } from "next";
import { Fraunces, Inter, IBM_Plex_Mono } from "next/font/google";
import "./globals.css";

const fraunces = Fraunces({
  variable: "--font-display",
  subsets: ["latin"],
  style: ["normal", "italic"],
  display: "swap",
});

const inter = Inter({
  variable: "--font-body",
  subsets: ["latin"],
  display: "swap",
});

const plexMono = IBM_Plex_Mono({
  variable: "--font-label",
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "MEIL Group — BRSR & ESG Intelligence Platform",
  description:
    "The enterprise sustainability intelligence platform of Megha Engineering & Infrastructures Limited. SEBI BRSR Core, NGRBC nine principles, CEA emission factors, and multi-tier ESG consolidation across 200+ project sites.",
  keywords: [
    "MEIL",
    "BRSR",
    "ESG",
    "SEBI",
    "sustainability reporting",
    "enterprise platform",
  ],
  authors: [{ name: "Megha Engineering & Infrastructures Limited" }],
  icons: {
    icon: "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'><circle cx='16' cy='16' r='16' fill='%23E11D2E'/><path d='M10 22V10l6 6 6-6v12' stroke='white' stroke-width='2.8' fill='none' stroke-linecap='round' stroke-linejoin='round'/></svg>",
  },
  openGraph: {
    title: "MEIL Group — BRSR & ESG Intelligence Platform",
    description:
      "Enterprise sustainability intelligence for the megaprojects powering India. SEBI BRSR Core aligned, NGRBC mapped, verified at source.",
    siteName: "MEIL Group ESG Platform",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${fraunces.variable} ${inter.variable} ${plexMono.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
