MEIL BRSR & ESG Landing Page — HTML, CSS and JavaScript

FILES
- index.html: Landing page
- style.css: Responsive layout and visual styles
- script.js: Mobile navigation and current footer year
- login.html: Login page UI demo

RUN LOCALLY
1. Extract/open this folder in VS Code or Antigravity.
2. Open index.html in a browser, or use VS Code Live Server.
3. Login and Get Started buttons open login.html.

NOTES
- No npm install or build process is needed.
- Photos and Google Fonts load from external services, so internet is needed for them.
- The red MEIL letter mark is a placeholder, not an official logo file. Replace it with an approved logo asset before publishing.
- The numbers shown are illustrative values from the supplied design; verify them before publishing.
- The login form is front-end demonstration only. It does not authenticate users. Add approved backend authentication/company SSO before production.
