/* ═══════════════════════════════════════════════════════════════════════════
   MEIL ESG PLATFORM — SEED
   ═══════════════════════════════════════════════════════════════════════════
   ⚠️  CONFIGURABLE MASTER DATA  ⚠️
   The project database contained no subsidiary / business-unit records, so —
   per the platform brief — this seed provisions a clearly-identified,
   replaceable master-data set. The division names below mirror the four
   flagship domains already published on the MEIL landing page (Transportation
   tunnels, Solar & renewables, Lift irrigation, Electric mobility). They are
   INTENDED TO BE REPLACED with the real organizational hierarchy: edit the
   arrays below and re-run `bun prisma/seed.ts`, or load them from your
   ERP/HRMS export. No other code hard-codes these names.
   ────────────────────────────────────────────────────────────────────────────
   Demo users are provisioned for testing every portal + role combination.
   Demo password for ALL seeded accounts:  Esg@2025
   (Remove demo accounts before production go-live.)
   ═══════════════════════════════════════════════════════════════════════════ */

import { PrismaClient } from "@prisma/client";
import { hashPassword } from "../src/lib/password";

const db = new PrismaClient();

/* ── CONFIGURABLE MASTER DATA ───────────────────────────────────────────────
   Transcribed from the user-provided workbook
   "MEIL_Subsidiary_Wise_Business_Units.xlsx" (sheet: Subsidiary-wise BU):
   7 subsidiaries, 16 business units, exact names & codes. ────────────────── */

const SUBSIDIARIES = [
  {
    code: "MEIL",
    name: "Megha Engineering & Infrastructures Ltd (MEIL Core)",
    sortOrder: 1,
    businessUnits: [
      { code: "IWEN", name: "Irrigation & Water Engineering Networks", sortOrder: 1 },
      { code: "HCIT", name: "Heavy Civil Infrastructure & Tunnels", sortOrder: 2 },
      { code: "HRP", name: "Hydrocarbons, Refinery & Pipelines", sortOrder: 3 },
      { code: "PTSE", name: "Power Transmission & Substation EPC", sortOrder: 4 },
    ],
  },
  {
    code: "OLECTRA",
    name: "Olectra Greentech Limited",
    sortOrder: 2,
    businessUnits: [
      { code: "EBMP", name: "Electric Bus Manufacturing Plant (Telangana)", sortOrder: 1 },
      { code: "EPBI", name: "EV Powertrain & Battery Integration Division", sortOrder: 2 },
      { code: "MTFO", name: "Municipal Transit Fleet Operations", sortOrder: 3 },
    ],
  },
  {
    code: "MCGDH",
    name: "Megha City Gas Distribution Holding",
    sortOrder: 3,
    businessUnits: [
      { code: "CGDN", name: "City Gas Distribution (CGD) Networks", sortOrder: 1 },
      { code: "CCDS", name: "CNG Compression & Dispensing Stations", sortOrder: 2 },
      { code: "PDIS", name: "PNG Domestic & Industrial Supply", sortOrder: 3 },
    ],
  },
  {
    code: "DRILLMEC",
    name: "Drillmec S.p.A.",
    sortOrder: 4,
    businessUnits: [
      { code: "ARAM", name: "Advanced Rig Automation & Manufacturing", sortOrder: 1 },
      { code: "GCDS", name: "Geothermal & Clean Drilling Solutions", sortOrder: 2 },
    ],
  },
  {
    code: "PETREVEN",
    name: "Petreven S.p.A.",
    sortOrder: 5,
    businessUnits: [
      { code: "GCOS", name: "Global Clean Oilfield Services", sortOrder: 1 },
    ],
  },
  {
    code: "MSOLAR",
    name: "MEIL Solar Energy Limited",
    sortOrder: 6,
    businessUnits: [
      { code: "CUSP", name: "Charanka & Utility-Scale Solar Parks", sortOrder: 1 },
      { code: "ICFS", name: "Industrial Canal-Top & Floating Solar", sortOrder: 2 },
    ],
  },
  {
    code: "MHYDRO",
    name: "MEIL Hydro Power Limited",
    sortOrder: 7,
    businessUnits: [
      { code: "MPSP", name: "Multi-Stage Pumped Storage Projects", sortOrder: 1 },
    ],
  },
];

/* earlier placeholder master data — kept for referential integrity (audit trail)
   but deactivated, so portal dropdowns show exactly the 7 workbook subsidiaries */
const RETIRED_SUBSIDIARY_CODES = ["SUB-INF", "SUB-ENE", "SUB-WTR", "SUB-MOB"];
const RETIRED_BU_CODES = [
  "BU-ZOJILA", "BU-HWYEPC", "BU-CHARANKA", "BU-SOLAREPC",
  "BU-KLRIS", "BU-WGRID", "BU-EBUS", "BU-EVMFG",
];

const DEMO_PASSWORD = "Esg@2025";

const USERS: Array<{
  employeeId: string;
  name: string;
  email: string;
  role: string;
  subCode?: string;
  buCode?: string;
}> = [
  /* Group */
  { employeeId: "GRP-0001", name: "R. Venkataramana", email: "group.admin@meil.in", role: "GROUP_ADMIN" },
  { employeeId: "GRP-0002", name: "S. Anitha Rao", email: "org.manager@meil.in", role: "ORG_MANAGER" },
  /* Subsidiary — MEIL Core */
  { employeeId: "SUB-1001", name: "K. Srinivas", email: "sub.admin.core@meil.in", role: "SUBSIDIARY_ADMIN", subCode: "MEIL" },
  { employeeId: "SUB-1002", name: "M. Lakshmi", email: "sub.mgr.core@meil.in", role: "SUBSIDIARY_MANAGER", subCode: "MEIL" },
  /* Subsidiary — Olectra Greentech (cross-scope test account) */
  { employeeId: "SUB-2001", name: "P. Karthik", email: "sub.mgr.olectra@meil.in", role: "SUBSIDIARY_MANAGER", subCode: "OLECTRA" },
  /* Subsidiary — Megha City Gas Distribution */
  { employeeId: "SUB-3001", name: "D. Praveen", email: "sub.admin.mcgdh@meil.in", role: "SUBSIDIARY_ADMIN", subCode: "MCGDH" },
  /* Business units */
  { employeeId: "BU-1001", name: "T. Naveen", email: "bu.admin.iwen@meil.in", role: "BU_ADMIN", subCode: "MEIL", buCode: "IWEN" },
  { employeeId: "BU-1002", name: "J. Harika", email: "bu.mgr.iwen@meil.in", role: "BU_MANAGER", subCode: "MEIL", buCode: "IWEN" },
  { employeeId: "BU-2001", name: "V. Mohan", email: "bu.mgr.ebmp@meil.in", role: "BU_MANAGER", subCode: "OLECTRA", buCode: "EBMP" },
  { employeeId: "BU-3001", name: "A. Divya", email: "bu.admin.cusp@meil.in", role: "BU_ADMIN", subCode: "MSOLAR", buCode: "CUSP" },
];

/* ── seed (idempotent upserts — no duplicates) ────────────────────────────── */

async function main() {
  console.log("— Seeding configurable master data —");

  const passwordHash = await hashPassword(DEMO_PASSWORD);

  for (const s of SUBSIDIARIES) {
    const subsidiary = await db.subsidiary.upsert({
      where: { code: s.code },
      update: { name: s.name, sortOrder: s.sortOrder, isActive: true },
      create: { code: s.code, name: s.name, sortOrder: s.sortOrder },
    });

    for (const b of s.businessUnits) {
      await db.businessUnit.upsert({
        where: { code: b.code },
        update: {
          name: b.name,
          sortOrder: b.sortOrder,
          subsidiaryId: subsidiary.id,
          isActive: true,
        },
        create: {
          code: b.code,
          name: b.name,
          sortOrder: b.sortOrder,
          subsidiaryId: subsidiary.id,
        },
      });
    }
  }

  console.log(`  ✓ ${SUBSIDIARIES.length} subsidiaries, ${SUBSIDIARIES.reduce((n, s) => n + s.businessUnits.length, 0)} business units`);

  /* retire the earlier placeholder hierarchy (dropdowns filter isActive) */
  await db.subsidiary.updateMany({
    where: { code: { in: RETIRED_SUBSIDIARY_CODES } },
    data: { isActive: false },
  });
  await db.businessUnit.updateMany({
    where: { code: { in: RETIRED_BU_CODES } },
    data: { isActive: false },
  });

  for (const u of USERS) {
    const subsidiary = u.subCode
      ? await db.subsidiary.findUnique({ where: { code: u.subCode } })
      : null;
    const businessUnit = u.buCode
      ? await db.businessUnit.findUnique({ where: { code: u.buCode } })
      : null;

    await db.user.upsert({
      where: { employeeId: u.employeeId },
      update: {
        name: u.name,
        email: u.email,
        role: u.role,
        passwordHash,
        subsidiaryId: subsidiary?.id ?? null,
        businessUnitId: businessUnit?.id ?? null,
        isActive: true,
      },
      create: {
        employeeId: u.employeeId,
        name: u.name,
        email: u.email,
        role: u.role,
        passwordHash,
        subsidiaryId: subsidiary?.id ?? null,
        businessUnitId: businessUnit?.id ?? null,
      },
    });
  }

  console.log(`  ✓ ${USERS.length} users (demo password: ${DEMO_PASSWORD})`);
  console.log("— Seed complete —");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
